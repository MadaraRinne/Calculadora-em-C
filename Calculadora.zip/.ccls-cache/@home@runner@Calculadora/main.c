#include <math.h>;
#include <stdio.h>;
int main (void)
{
  float num1, num2;
  int operacao;
  do{ 
printf("\n\t Bem vindo, meu nome é Leandro dos Santos Mello e sou o criador dessa calculadora, estou cursando Analise e Desenvolvimento de Sistemas na Universidade La Salle, de Canoas, minha matricula é a de numero 202214127 \n\t Digite o numero da operacao que voce deseja realizar \n\t 1- Raiz Quadrada \n\t 2- Soma \n\t 3-Subtracao \n\t 4- Multiplicacao \n\t 5- Divisao \n\t 6- Potenciacao");
  scanf("%d", &operacao);
switch(operacao){
  case 1:
printf ("\nDigite um numero: ");
scanf ("%f", &num1);
float raiz=sqrt(num1);
printf ("Resultado: %0.1f", raiz);
     printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
  case 2:
printf ("\nDigite um numero: ");
scanf ("%f", &num1);
  printf ("\nDigite outro numero: ");
  scanf ("%f", &num2);
float Soma= num1 + num2;
printf("Resultado: %0.1f", Soma);
     printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
case 3:
  printf ("\nDigite um numero: ");
scanf ("%f", &num1);
  printf ("\nDigite outro numero: ");
  scanf ("%f", &num2);
float Subtracao= num1 - num2;
printf("Resultado: %0.1f", Subtracao);
   printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
case 4:
printf ("\nDigite um numero: ");
scanf ("%f", &num1);
  printf ("\nDigite outro numero: ");
  scanf ("%f", &num2);
float Multiplicacao= num1 * num2;
printf("Resultado: %0.1f", Multiplicacao);
   printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
case 5:
printf ("\nDigite um Dividendo: ");
scanf ("%f", &num1);
  printf ("\nDigite o Divisor: ");
  scanf ("%f", &num2);
float Divisao= num1 / num2;
printf("Resultado: %0.1f", Divisao);
   printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
case 6:
printf ("\nDigite um numero base: ");
scanf ("%f", &num1);
  printf ("\nDigite outro numero expoente: ");
  scanf ("%f", &num2);
float Potencia= pow(num1, num2);
printf("Resultado: %0.1f", Potencia);
  printf("\n Digite 1 para continuar: ");
    scanf("%i", &operacao);
break;
  default:
printf("\n validar");
  }
   }while (operacao=1);
    }